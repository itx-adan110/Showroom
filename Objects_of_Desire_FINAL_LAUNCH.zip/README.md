# OBJECTS OF DESIRE — FINAL

This is the final single-page front-end package.

## Core experience
- Editorial ivory/graphite art direction based on the supplied reference.
- Real browser 3D via `<model-viewer>`.
- Primary 3D asset: Three.js Ferrari 458 Italia example model.
- Automatic fallback: Khronos/Darmstadt concept-car GLB if the primary asset cannot be fetched.
- Touch/mouse orbit, pinch/scroll zoom, auto-rotate and camera presets.
- 15 real marques and real model names.
- Real automotive photography links/imagery, not AI-generated car art.
- Responsive mobile/desktop layout.
- Private viewing form (front-end demo until a backend is connected).

## 3D asset attribution / licensing
The primary Ferrari model is the model used by the Three.js “car materials” example, which identifies it as a Ferrari 458 Italia model by vicent091036.
Three.js example reference:
https://threejs.org/examples/webgl_materials_car

The fallback concept car is from the Khronos glTF Sample Assets ecosystem and is documented as CC BY 4.0 in the public demo that packages it:
https://github.com/studio-public-demos/car-concept-3d-dashboard

Before commercial use, review the applicable asset licenses and attribution requirements.

## Photography
The gallery uses real Unsplash-hosted photography and links to the corresponding photo pages. Unsplash licensing terms apply.

## Deploy
Upload `index.html` to GitHub Pages, Cloudflare Pages, Netlify or Vercel. HTTPS hosting is recommended because the 3D model and fonts are remote web assets.

## Important
This is a front-end showroom. It does not claim affiliation with any of the automotive marques named in the collection.
